<?php

/* events/details.html.twig */
class __TwigTemplate_1f16e9262b136b5f9e73294d900384c8a38df26e27ec21b0fc478daa135fdc49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "events/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "events/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "events/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
        <a class=\"btn btn-default\" href=\"/\">Back to Overview</a>

        <hr>

        <h2 class=\"page-header\">";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "name", array()), "html", null, true);
        echo "</h2>

        <ul class=\"list-group\">

                <li class=\"list-group-item\"><img src='";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "image", array()), "html", null, true);
        echo "' alt=\"\" border=3 height=250 width=300></img></li>

                <li class=\"list-group-item\">Capacity: ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "capacity", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\">Email: ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "email", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\">Phone No.: ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "phoneno", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\">Address: ";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "address", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\">Postal Code: ";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "postalcode", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\">City: ";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "city", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\"><a href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "URL", array()), "html", null, true);
        echo "\">URL: ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "URL", array()), "html", null, true);
        echo "</a></li>

                <li class=\"list-group-item\">Type: ";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "type", array()), "html", null, true);
        echo "</li>

                <li class=\"list-group-item\">Starting Time & Date: <strong> ";
        // line 31
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "startdate", array()), "F j, Y, g:i a"), "html", null, true);
        echo " </strong> 

                <li class=\"list-group-item\">Ending Time & Date: <strong> ";
        // line 33
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "enddate", array()), "F j, Y, g:i a"), "html", null, true);
        echo " </strong>

                 <li class=\"list-group-item\">Description: ";
        // line 35
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["event"]) ? $context["event"] : $this->getContext($context, "event")), "description", array()), "html", null, true);
        echo "</li>

                </li>

        </ul>

      

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "events/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 35,  115 => 33,  110 => 31,  105 => 29,  98 => 27,  93 => 25,  88 => 23,  83 => 21,  78 => 19,  73 => 17,  68 => 15,  63 => 13,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

        <a class=\"btn btn-default\" href=\"/\">Back to Overview</a>

        <hr>

        <h2 class=\"page-header\">{{event.name}}</h2>

        <ul class=\"list-group\">

                <li class=\"list-group-item\"><img src='{{event.image}}' alt=\"\" border=3 height=250 width=300></img></li>

                <li class=\"list-group-item\">Capacity: {{event.capacity}}</li>

                <li class=\"list-group-item\">Email: {{event.email}}</li>

                <li class=\"list-group-item\">Phone No.: {{event.phoneno}}</li>

                <li class=\"list-group-item\">Address: {{event.address}}</li>

                <li class=\"list-group-item\">Postal Code: {{event.postalcode}}</li>

                <li class=\"list-group-item\">City: {{event.city}}</li>

                <li class=\"list-group-item\"><a href=\"{{event.URL}}\">URL: {{event.URL}}</a></li>

                <li class=\"list-group-item\">Type: {{event.type}}</li>

                <li class=\"list-group-item\">Starting Time & Date: <strong> {{event.startdate|date('F j, Y, g:i a')}} </strong> 

                <li class=\"list-group-item\">Ending Time & Date: <strong> {{event.enddate|date('F j, Y, g:i a')}} </strong>

                 <li class=\"list-group-item\">Description: {{event.description}}</li>

                </li>

        </ul>

      

{% endblock %}", "events/details.html.twig", "/Applications/MAMP/htdocs/eventmgmt/app/Resources/views/events/details.html.twig");
    }
}
