<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Events;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\TextType;

use Symfony\Component\Form\Extension\Core\Type\TextareaType;

use Symfony\Component\Form\Extension\Core\Type\IntegerType;

use Symfony\Component\Form\Extension\Core\Type\DateTimeType;

use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventsController extends Controller

{

    /**

     * @Route("/", name="events_list")

     */

    public function listAction(){

        $events = $this->getDoctrine()->getRepository('AppBundle:Events')->findAll();

        // replace this example code with whatever you need

        return $this->render('events/index.html.twig', array('events'=>$events));

    }

     /**

     * @Route("/events/create", name="events_create")

     */

    public function createAction(Request $request){

        $event = new events;

        $form = $this->createFormBuilder($event)

        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('URL', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('type', ChoiceType::class, array('choices'=>array('Dance'=>'Dance', 'Concert'=>'Concert', 'Cinema'=>'Cinema'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
        ->add('capacity', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phone_no', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('postal_code', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

    ->add('start_date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('end_date', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))


    ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))

        ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){

            //fetching data

            $name = $form['name']->getData();

            $image = $form['image']->getData();

            $email = $form['email']->getData();

            $address = $form['address']->getData();

            $city = $form['city']->getData();

            $URL = $form['URL']->getData();

            $description = $form['description']->getData();

            $type = $form['type']->getData();

            $capacity = $form['capacity']->getData();

            $phone_no = $form['phone_no']->getData();

            $postal_code = $form['postal_code']->getData();

            $start_date = $form['start_date']->getData();

            $end_date = $form['end_date']->getData();

            // $now = new\DateTime('now');

            $event->setName($name);

            $event->setImage($image);

            $event->setEmail($email);

            $event->setAddress($address);

            $event->setCity($city);

            $event->setURL($URL);

            $event->setDescription($description);

            $event->setType($type);

            $event->setCapacity($capacity);

            $event->setPhoneNo($phoneno);

            $event->setPostalCode($postalcode);

            $event->setStartDate($startdate);

            $event->setEndDate($enddate);

            // $event->setCreateDate($now);

            $em = $this->getDoctrine()->getManager();

            $em->persist($event);

            $em->flush();

            $this->addFlash(

                    'notice',

                    'Event Added'

                    );

            return $this->redirectToRoute('events_list');

        }

        // replace this example code with whatever you need

        return $this->render('events/create.html.twig', array('form' => $form->createView()));

    }

     /**

     * @Route("/events/edit/{id}", name="events_edit")

     */

    public function editAction($id, Request $request){

    $event = $this->getDoctrine()->getRepository('AppBundle:Events')->find($id);

            $event->setName($event->getName());

            $event->setImage($event->getImage());

            $event->setEmail($event->getEmail());

            $event->setAddress($event->getAddress());

            $event->setCity($event->getCity());

            $event->setURL($event->getURL());
            
            $event->setDescription($event->getDescription());

            $event->setType($event->getType());

            $event->setCapacity($event->getCapacity());

            $event->setPhoneNo($event->getPhoneNo());

            $event->setPostalCode($event->getPostalCode());

            $event->setStartDate($event->getStartDate());

            $event->setEndDate($event->getEndDate());


            $form = $this->createFormBuilder($event)

        ->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('email', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('city', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('URL', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('description', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

        ->add('type', ChoiceType::class, array('choices'=>array('Dance'=>'Dance', 'Concert'=>'Concert', 'Cinema'=>'Cinema'),'attr' => array('class'=> 'form-control', 'style'=>'margin-botton:15px')))
        ->add('capacity', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('phoneno', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('postalcode', IntegerType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

    ->add('startdate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))
    ->add('enddate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))


    ->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))

        ->getForm();

        $form->handleRequest($request);


        if($form->isSubmitted() && $form->isValid()){

            //fetching data

            $name = $form['name']->getData();

            $image = $form['image']->getData();

            $email = $form['email']->getData();

            $address = $form['address']->getData();

            $city = $form['city']->getData();

            $URL = $form['URL']->getData();

            $description = $form['description']->getData();

            $type = $form['type']->getData();

            $capacity = $form['capacity']->getData();

            $phoneno = $form['phoneno']->getData();

            $postalcode = $form['postalcode']->getData();

            $startdate = $form['startdate']->getData();

            $enddate = $form['enddate']->getData();

            $em = $this->getDoctrine()->getManager();

            $event = $em->getRepository('AppBundle:Events')->find($id);

            $event->setName($name);

            $event->setImage($image);

            $event->setEmail($email);

            $event->setAddress($address);

            $event->setCity($city);

            $event->setURL($URL);

            $event->setDescription($description);

            $event->setType($type);

            $event->setCapacity($capacity);

            $event->setPhoneNo($phoneno);

            $event->setPostalCode($postalcode);

            $event->setStartDate($startdate);

            $event->setEndDate($enddate);

         

            $em->flush();

            $this->addFlash(

                    'notice',

                    'Event Updated'

                    );

            return $this->redirectToRoute('events_list');

        }

        return $this->render('events/edit.html.twig', array('event' => $event, 'form' => $form->createView()));
    }

     /**

     * @Route("/events/details/{id}", name="events_details")

     */

    public function detailsAction($id){

                $event = $this->getDoctrine()->getRepository('AppBundle:Events')->find($id);

        return $this->render('events/details.html.twig', array('event' => $event));

    }
       /**

     * @Route("/events/delete/{id}", name="events_delete")

     */

    public function deleteAction($id){

                 $em = $this->getDoctrine()->getManager();

            $event = $em->getRepository('AppBundle:Events')->find($id);

            $em->remove($event);

             $em->flush();

            $this->addFlash(

                    'notice',

                    'Event Removed'

                    );

             return $this->redirectToRoute('events_list');

    }

 }
