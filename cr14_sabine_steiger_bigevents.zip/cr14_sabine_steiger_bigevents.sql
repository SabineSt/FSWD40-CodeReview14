-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 22. Jul 2018 um 16:49
-- Server-Version: 5.6.38
-- PHP-Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr14_sabine_steiger_bigevents`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone_no` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `postal_code` int(11) NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Daten für Tabelle `events`
--

INSERT INTO `events` (`id`, `name`, `start_date`, `end_date`, `description`, `image`, `capacity`, `email`, `phone_no`, `address`, `postal_code`, `city`, `URL`, `type`) VALUES
(2, 'LA FAKTORIA CHOREOGRAPHIC CENTRE', '2018-07-29 19:00:00', '2018-07-29 21:30:00', 'La Faktoria Choreographic Center will open its doors in    January 2019 in Pamplona north of Spain under the direction of LAIDA ALDAZ, MARTA CORONADO and CARMEN LARRAZ. It will be a place where choreographers will have their space to create. We will encou', 'https://www.impulstanz.com/media/sys_autoimg/mono_631ffb550907a66239afddc512694d9e.jpg', 60, 'martacoronado@gmail.com', 8897689, 'Arsenal 34', 1100, 'Vienna', 'https://www.impulstanz.com/auditions/', 'Dance'),
(3, 'CIE. MARIE CHOUINARD', '2018-08-05 18:30:00', '2018-08-05 20:30:00', 'Dem Orpheus und der Eurydike läutet eine königliche Glocke, im Mai 1955 gab es einen besonderen Sonntagmorgen und im Herzchakra ereignet sich ein Beben. Die große kanadische Choreografin Marie Chouinard hat sich während der gesamten vierzig Jahre ihres kü', 'https://www.impulstanz.com/media/sys_autoimg/5d4d268875005a4868ae590d9e0a756e.jpg', 85, 'cie.dorner@hotmail.com', 8774567, 'Arsenal 89', 1100, 'Vienna', 'https://www.impulstanz.com/performances/2018/id1202/', 'Dance'),
(4, 'Private Anatomy Lesson \r\nThe Body, desire for symmetry', '2018-08-15 16:30:00', '2018-08-15 19:30:00', 'In den letzten Jahren hat Anne Juren eine Fantasmische Anatomie entwickelt, die genau so real ist wie ein Knochen. In Anatomie bei ImPulsTanz 2017 erweiterte sie die Vorstellung des Körpers und seiner Grenzen durch eine Textlandschaft mit poetischen, phan', 'https://www.impulstanz.com/media/sys_autoimg/117ced325a2acfd56663e973800ce509.jpg', 34, 'anne@mymail.fr', 8937927, 'Avenue Droi 57', 7834, 'Lyon', 'https://www.impulstanz.com/performances/2018/id1257/', 'Dance'),
(5, 'Footage, Avoiding deLIFEath, ImPulsTanz 2017', '2018-07-31 17:30:00', '2018-07-31 20:45:00', 'Ivo Dimchev gewährt Einblick in die Mitschnitte seiner sechstägigen Performance Avoiding deLIFEath, die 2017 in der mumok Hofstallung stattgefunden hat.', 'https://www.impulstanz.com/media/sys_autoimg/6b8040696b39c5cb970e1d17b5eba144.jpg', 98, 'dimchov@mymail.com', 7843562, 'Krushkov Lum 56', 9834, 'Paris', 'https://www.impulstanz.com/performances/2018/id1265/', 'Dance'),
(6, 'UnBearable Darkness', '2018-07-27 18:30:00', '2018-07-27 23:30:00', 'Für ihn ist der japanische Butoh-Tanz eine Rebellion gegen die westliche Tanzkultur und die Suche nach einer neuen choreografischen Sprache. Choy Ka Fai ist in Wien seit seinem Projekt Soft Machine im Weltmuseum bei ImPulsTanz 2015 bekannt. Jetzt beschwör', 'https://www.impulstanz.com/media/sys_autoimg/db2992df351d64a300b73a901ffdadf6.jpg', 100, 'hijikata@mymail.at', 89756432, 'Nihamsho Yakoto 34', 879998, 'Tokio', 'https://www.impulstanz.com/performances/2018/id1204/', 'Dance'),
(7, 'Movimiento Constante', '2018-07-22 18:30:00', '2018-07-22 20:30:00', 'Wir von Movimiento Constante, haben eine Suche gestartet, angetrieben durch den Austausch unserer Bewegungspraktiken, die mehrere Tanztechniken und Sprachen (Körper, Klang, Bild) verbinden, von unserem Interesse an den Besonderheiten und Bewegungen jeder ', 'https://www.impulstanz.com/media/sys_autoimg/c78a1d07652de040461bba9858c05d6a.jpg', 80, 'jesus.gueraldi@hotmail.com', 8897456, 'Lainzer Tiergarten 33', 1100, 'Vienna', 'https://www.impulstanz.com/workshops/2018/id3799/', 'Dance'),
(8, 'Enter Shikari', '2019-03-10 21:30:00', '2019-03-11 00:30:00', 'Enter Shikari haben schon immer gerne die Genregrenzen überschritten und entwickelten über die Jahre ihren ganz eigenen originellen Stil. Post-Hardcore ist die Grundlage - dazu kommen Ausflüge in die Elektrosounds, Dubstep- oder Drum’n’Bass-Rhythmen. Zusa', 'https://images.ecosia.org/83MDo0UEUWaBTVhUB7akldc_1Lg=/0x390/smart/https%3A%2F%2Fwww.upsetmagazine.com%2Fwp-content%2Fuploads%2F2017%2F09%2FEnter-Shikari-SLB-Sept-2017-6.jpg', 99, 'enter.shikari@mimi.at', 7364763, 'Manhattan Strasse 54', 7834, 'Berlin', 'https://www.eventim.de/enter-shikari-tickets.html?affiliate=EVE&doc=artistPages%2Ftickets&fun=artist&action=tickets&erid=2088253&includeOnlybookable=true', 'Concert'),
(9, 'Danko Jones', '2019-05-22 21:30:00', '2019-05-23 00:30:00', 'Danko Jones ist eine kanadische Garage-Blues-Rock-Band um den kanadischen Sänger und Gitarristen mit gleichlautendem Künstlernamen. Dazu gehören noch John Calabrese, der Bassist, und Dan Cornelius, der Schlagzeuger. Ehemaliger Schlagzeuger ist Damon Richa', 'https://images.ecosia.org/9eT5-wtABmpRHdLEPBcNv5Og4l0=/0x390/smart/http%3A%2F%2Fwww.lordsofrock.net%2Fwp-content%2Fuploads%2F2014%2F11%2Fdankojcnc.jpg', 159, 'danko@gmail.com', 453872, 'Road to Hell 77', 47389, 'Vienna', 'https://www.eventim.de/danko-jones-tickets.html?affiliate=EVE&doc=artistPages%2Ftickets&fun=artist&action=tickets&erid=1807601&includeOnlybookable=true', 'Concert'),
(10, 'Annisokay', '2019-04-14 19:30:00', '2019-04-14 23:30:00', 'Neues Album, neue Tour! Im Herbst 2018 schießen Annisokay ein neues Album nach und damit durch Deutschland, Österreich und Groß-Britannien. Die Fully-Automatic Tour 2018, kurz und knackig FAT18. Mit dem neuen Album Arms dürfen sich die heimischen Fans auf', 'https://images.ecosia.org/MpuIGtBAJIoezDfDiFdHPSeOifs=/0x390/smart/http%3A%2F%2Fa3.mzstatic.com%2Fus%2Fr30%2FMusic3%2Fv4%2F4a%2Fde%2F8c%2F4ade8cf0-9907-1e3c-44fc-c68e62727127%2Fcover1200x1200.jpeg', 99, 'anni@mim.com', 473847, 'Dresdner Strasse 80', 4398, 'Leipzig', 'https://www.eventim.de/annisokay-fully-automatic-tour-2018-tickets.html?affiliate=EVE&doc=artistPages%2Ftickets&fun=artist&action=tickets&erid=2088429&includeOnlybookable=true', 'Concert'),
(11, 'While She Sleeps', '2018-10-30 20:30:00', '2018-10-30 00:00:00', 'While She Sleeps (formed in 2006) are a British five-piece metalcore band who rose to prominence with the release of their mini-album “The North Stands for Nothing” in 2010, hailing from Sheffield, England, UK.', 'https://images.sk-static.com/images/media/profile_images/artists/2175276/huge_avatar', 230, 'while@aon.at', 74392883, 'Meininger Strasse 80', 5647, 'Vienna', 'https://www.songkick.com/artists/2175276-while-she-sleeps', 'Concert'),
(12, 'Twenty One Pilots', '2018-12-30 20:30:00', '2018-12-30 23:30:00', 'TWENTY ØNE PILØTS MIT ZWEI NEUEN SONGS ZURÜCK\r\nJUMPSUIT UND „NICO AND THE NINERS“ AB SOFORT BEI ALLEN STREAMING SERVICES\r\nUMFANGREICHE BANDITO TOUR ANGEKÜNDIGT\r\nAB MITTE FEBRUAR LIVE IN HAMBURG, BERLIN, ZÜRICH, STUTTGART UND KÖLN\r\nHEISS ERWARTETES NEUES A', 'http://img2-ak.lst.fm/i/u/arO/fbc39c88bf79db8835b6d3c8cc429179', 600, 'twenty@mymail.com', 7564738, 'Myway 87', 4392, 'Salzburg', 'https://www.viagogo.at/Konzert-Tickets/Rock-und-Pop/Twenty-One-Pilots-Karten?AffiliateID=49&PCID=PSATBINCONTWENT7CB8990868&AdID=83700356607872&gclid=d3f4659a0e33143642923ecea6c4c945&gclid=d3f4659a0e33143642923ecea6c4c945&ps_p=1&ps_p=1&ps_ag=13392053479622', 'Concert'),
(13, 'HER', '2018-08-11 21:30:00', '2018-08-11 22:15:00', 'Theodore Twombly verdient sein Geld als Autor handgeschriebener Briefe, die in der nahen Zukunft eine Seltenheit geworden sind. Programme haben die Schreibaufgaben der Menschen vollständig übernommen. Theodore lebt inzwischen alleine in einer Wohnung, die', 'http://volxkino.at/wp-content/uploads/2018/05/HER_hp.jpg', 77, 'volx@kino.at', 3787483, 'Karmelitermarkt', 1020, 'Vienna', 'http://volxkino.at/event/her/', 'Cinema'),
(14, 'MR. LONG', '2018-07-31 20:30:00', '2018-07-31 22:30:00', 'Ein taiwanesischer Auftragskiller strandet in einer japanischen Vorstadt. Seine Mission ist missglückt und ihm bleiben fünf Tage, um Geld für die geplante Rückreise aufzutreiben. Unvermittelt erhält er dabei Hilfe: Der kleine Jun weicht nicht von seiner S', 'http://volxkino.at/wp-content/uploads/2018/05/mrlong2_hp.jpg', 50, 'volx@kino.at', 48394739, 'Karmeliterplatz', 1020, 'Vienna', 'http://volxkino.at/event/mr-long/', 'Cinema'),
(15, 'DIE BESTE ALLER WELTEN', '2018-08-01 20:30:00', '2018-08-01 22:30:00', 'Adrian ist sieben und ein aufgeweckter Junge, der gern draußen spielt, wo der Stadtrand Salzburgs ihm als großes Abenteuerland erscheint. Seine Mutter Helga verbringt viel Zeit mit ihrem Sohn. Adrian genießt das. Für ihn ist es normal, dass sie, ihr Leben', 'http://volxkino.at/wp-content/uploads/2018/05/Die-beste-aller-Welten-01_14.08_%C2%A9Polyfilm.jpg', 40, 'volx@kino.at', 458394, 'Ocwirkgasse 13', 1200, 'Vienna', 'http://volxkino.at/event/die-beste-aller-welten/', 'Cinema');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
